//2021112030 Ȳ����
#include <stdio.h>
int main(void) {
    int n;
    scanf("%d", &n);
    int a[8];

    for (int i = 0; i < 8; i++) {
        a[i] = n % 2;
        n /= 2;
    }
    for (int i = 0; i < 8; i++) {
        printf(a[i]);
    }
    int b[4];
    for (int i = 0; i < 4; i++) {
        if (a[i] == 0 && a[i + 4] == 0) {
            b[i] = 0;
        }
        else {
            b[i] = 1;
        }
    }
    printf(b[3]);
}