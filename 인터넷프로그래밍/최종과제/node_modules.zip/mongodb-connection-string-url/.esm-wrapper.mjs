import mod from "./lib/index.js";

export default mod["default"];
export const CommaAndColonSeparatedRecord = mod.CommaAndColonSeparatedRecord;
